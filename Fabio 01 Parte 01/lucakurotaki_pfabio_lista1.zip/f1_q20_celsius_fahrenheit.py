#Entrada

celsius = float(input("Insira a temperatura em Cº: "))

#Processamento

fahrenheit = (celsius*9+160)/5

#Saída

print("A temperatura em Fº é: %.2f" %fahrenheit)
