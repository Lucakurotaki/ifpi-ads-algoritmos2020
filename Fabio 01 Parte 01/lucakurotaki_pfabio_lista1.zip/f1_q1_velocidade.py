# Entrada
print ('Bem-vindo a ferramenta de conversão de velocidade!')
velocidade_ms = float(input('Digite a velocidade em m/s: '))

# Processamento
velocidade_kmh = velocidade_ms * 3.6

# Saída
print ('A velocidade em km/h é ', velocidade_kmh)