#Entrada

raio = float(input("Digite o valor do raio: "))

#Processamento

circunferencia = raio*2*3.14

#Saída

print("O comprimento da circunferência é: %.2f" %circunferencia)
