#Entrada

km = float(input("Digite a distância em km: "))

#Processamento

m = km*1000

#Saída

print("A distância em m é: %.2f" %m)
