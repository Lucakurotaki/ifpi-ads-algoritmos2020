#Entrada

base = float(input("Digite a medida da base: "))
altura = float(input("Digite o valor da altura: "))

#Processamento

triangulo = base*altura/2

#Saída

print("A áre do triângulo é: ",triangulo)
