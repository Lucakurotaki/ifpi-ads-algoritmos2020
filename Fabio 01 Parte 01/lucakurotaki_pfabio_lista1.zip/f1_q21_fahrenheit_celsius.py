#Entrada

fahrenheit = float(input("Digite a temperatura em Fº: "))

#Processamento

celsius = (5*fahrenheit-160)/9

#Saída

print("A temperatura em Cº é: %.2f" %celsius)
