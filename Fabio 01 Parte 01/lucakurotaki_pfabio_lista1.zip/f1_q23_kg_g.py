#Entrada

kg = float(input("'Digite a massa em kg: "))

#Processamento

g = kg*1000

#Saída

print("A massa em g é: %.2f" %g)
