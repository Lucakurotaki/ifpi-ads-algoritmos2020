# Entrada
numero1 = float(input ('Insira o primeiro número: '))
numero2 = float(input ('Insira o segundo número: '))

# Saída
print ('A ordem inversa dos números é: ', numero2, numero1)