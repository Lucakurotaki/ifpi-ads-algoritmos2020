# Entrada
print ('Bem-vindo a ferramenta de conversão de unidades de tempo!')
horas = int(input ('Digite o valor em horas: '))
minutos = int(input ('Digite o valor em minutos: '))

# Processamento
minutos_final = horas * 60 + minutos

# Saída
print ('O valor total em minutos é: ', minutos_final)