#Entrada

raio = float(input("Digite a medida do raio: "))

#Processamento

esfera = 4*3.14*(raio**3)/3

#Saída

print("O volume da esfera é: %.2f" %esfera)
