# Entrada
print ('Bem-vindo a ferramenta de conversão de velocidade!')
velocidade_kmh = float(input('Digite a velocidade em km/h: '))

# Processamento
velocidade_ms = velocidade_kmh / 3.6

# Saída
print ('A velocidade em km/h é %.2f' %velocidade_ms)