# Entrada
print ('Este programa irá somar os 2 primeiros números que inserir e fará a diferença dos 2 últimos')
numero1 = float(input ('Digite o primeiro número: '))
numero2 = float(input ('Digite o segundo número: '))
numero3 = float(input ('Digite o terceiro número: '))

# Processamento
soma = numero1 + numero2
diferença = numero2 - numero3

# Saída
print ('A soma é {} e a diferença é {}'.format (soma, diferença))