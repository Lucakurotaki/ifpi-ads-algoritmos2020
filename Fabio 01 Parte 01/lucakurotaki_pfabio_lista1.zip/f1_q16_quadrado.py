#Entrada

lado = float(input("Digite a medida do lado: "))

#Processamento

quadrado = lado**2

#Saída

print("A área do quadrado é: ",quadrado)
