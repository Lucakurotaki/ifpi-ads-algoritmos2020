#Entrada

base = float(input("Digite a medida da base: "))
altura = float(input("Digite a medida da altura: "))

#Processamento

quadrilatero = base*altura

#Saída

print("A área do qudrilátero é: )",quadrilatero)
