# Entrada
print ('Bem-vindo a ferramenta de câmbio')
dolar = float(input ('Digite o valor em dólar: '))

# Processamento
real = dolar * 4.36

# Saída
print ('O valor em reais é: R$ %.2f' %real)